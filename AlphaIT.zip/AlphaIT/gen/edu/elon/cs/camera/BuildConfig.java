/** Automatically generated file. DO NOT MODIFY */
package edu.elon.cs.camera;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}